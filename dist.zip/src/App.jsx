import { useState } from "react";
import Agenda from "./pages/Agenda";
import Login from "./pages/Login";

export default function App() {

  const [logueado, setLogueado] = useState(false);

  if (!logueado) {
    return <Login onLogin={() => setLogueado(true)} />;
  }

  return <Agenda />;
}